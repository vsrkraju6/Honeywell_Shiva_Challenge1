package com.honeywell.RTST;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InsertCompanyServlet
 */
@WebServlet("/InsertCompanyServlet")
public class InsertCompanyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException  {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String compID = request.getParameter("compID");
		String stockVal = request.getParameter("stockVal");
		String currPrice = request.getParameter("currPrice");
		String PercentageChange = request.getParameter("PercentageChange");
		String weekHigh = request.getParameter("weekHigh");
		String weekLow = request.getParameter("weekLow");
		
		try {
			Driver d = null;
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}  
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hw", "root", "root");
			PreparedStatement pst = con.prepareStatement("insert into companies values(?, ?, ?, ?, ?, ?);");
			pst.setString(0, compID);
			pst.setString(1, stockVal);
			pst.setString(2, currPrice);
			pst.setString(3, PercentageChange);
			pst.setString(4, weekHigh);
			pst.setString(5, weekLow);
			int i = pst.executeUpdate();
			out.println(i+" Rows Inserted Succesfully");
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		/*Favourites favCom = new Favourites();
		favCom.setCompID(request.getParameter("compID"));
		favCom.setStockVal(request.getParameter("compID"));
		favCom.setCurrPrice(request.getParameter("currPrice"));
		favCom.setPercentageChange(request.getParameter("PercentageChange"));
		favCom.setWeekHigh(request.getParameter("weekHigh"));
		favCom.set*/
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

}
