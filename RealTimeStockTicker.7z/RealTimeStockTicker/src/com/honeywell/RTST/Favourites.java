package com.honeywell.RTST;

import java.util.ArrayList;

public class Favourites {
	
	ArrayList companies; 
	public ArrayList getCompanies() {
		return companies;
	}
	public void setCompanies(ArrayList companies) {
		this.companies = companies;
	}
	
	
}
