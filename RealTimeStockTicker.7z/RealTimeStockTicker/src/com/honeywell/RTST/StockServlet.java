package com.honeywell.RTST;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CompaniesList
 */
@WebServlet("/CompaniesList")
public class StockServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String value = request.getParameter("selection");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		if (value.equals("insert")) {

			response.sendRedirect("insert.jsp");
		}
		if (value.equals("view")) {

			response.sendRedirect("view.jsp");
		}

		out.print("<h1>Real Time Stocker<h1>");
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

}
