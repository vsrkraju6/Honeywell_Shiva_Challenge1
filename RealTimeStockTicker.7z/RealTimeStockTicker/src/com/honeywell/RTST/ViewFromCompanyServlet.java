package com.honeywell.RTST;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ViewFromCompanyServlet
 */
@WebServlet("/ViewFromCompanyServlet")
public class ViewFromCompanyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String company = request.getParameter("compID");
		ArrayList al = new ArrayList();
		
		al.add("ABC");
		al.add("600 USD");
		al.add("13.00");
		al.add("+17%");
		al.add("20");
		al.add("-9");
		
		/*try {
			Driver d = null;
			DriverManager.registerDriver(d);
			Connection con = DriverManager.getConnection("url", "user", "pwd");
			PreparedStatement pst = con.prepareStatement("select * from Companies where Name = ?;");
			pst.setString(0, company);
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()){
				al.add(rs.getString(0));
				al.add(rs.getString(1));
				al.add(rs.getString(2));
				al.add(rs.getString(3));
				al.add(rs.getString(4));
				al.add(rs.getString(5));
				}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		Favourites fs = new Favourites();
		fs.setCompanies(al);
		response.sendRedirect("viewCompany.jsp");
		 
	}

}
